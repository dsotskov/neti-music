<?php
$arModuleVersion = array(
	'VERSION' => '1.0.0',
	'VERSION_DATE' => "2016-09-12 00:00:00",
);
?>